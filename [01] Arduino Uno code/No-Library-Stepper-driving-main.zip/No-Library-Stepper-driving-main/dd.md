cx xc x
